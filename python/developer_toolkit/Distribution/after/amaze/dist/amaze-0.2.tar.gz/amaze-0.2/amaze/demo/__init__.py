"""
amaze.demo module
~~~~~~~~~~~~~~~~~
"""

__author__ = 'Reindert-Jan Ekker'
